"""
storage.py — SQLite persistence for OWNER MODE v1
Tables: known_jobs, job_history, cookies, errors
"""
import sqlite3
import json
import logging
from datetime import datetime
from config import DB_PATH, now_london

log = logging.getLogger(__name__)

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Create all tables if they don't exist."""
    with get_conn() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS known_jobs (
                job_id      TEXT PRIMARY KEY,
                title       TEXT,
                location    TEXT,
                pay         REAL,
                contract    TEXT,
                found_at    TEXT,
                alerted_at  TEXT
            );

            CREATE TABLE IF NOT EXISTS job_history (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id      TEXT,
                title       TEXT,
                location    TEXT,
                postcode    TEXT,
                pay         REAL,
                contract    TEXT,
                hours       TEXT,
                schedule    TEXT,
                first_day   TEXT,
                found_at    TEXT,
                job_json    TEXT
            );

            CREATE TABLE IF NOT EXISTS cookies (
                account_id  INTEGER PRIMARY KEY,
                cookie_json TEXT,
                saved_at    TEXT,
                hvhcid      TEXT
            );

            CREATE TABLE IF NOT EXISTS errors (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                error_type  TEXT,
                message     TEXT,
                occurred_at TEXT
            );

            CREATE TABLE IF NOT EXISTS applications (
                job_id       TEXT PRIMARY KEY,
                app_id       TEXT,
                status       TEXT,
                prepared_at  TEXT,
                submitted_at TEXT
            );
        """)
    log.info(f"✅ DB initialised: {DB_PATH}")

# ─── KNOWN JOBS ──────────────────────────────────────────────────────────────
def is_known_job(job_id: str) -> bool:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT 1 FROM known_jobs WHERE job_id = ?", (job_id,)
        ).fetchone()
    return row is not None

def mark_job_known(job: dict):
    now = now_london().isoformat()
    with get_conn() as conn:
        conn.execute("""
            INSERT OR IGNORE INTO known_jobs
            (job_id, title, location, pay, contract, found_at, alerted_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            job["id"], job.get("title"), job.get("location"),
            job.get("pay"), job.get("contract"), job.get("found_at", now), now
        ))
    log.info(f"💾 [SAVED] {job['id']} — {job.get('location')}")

def get_known_job_ids() -> set:
    with get_conn() as conn:
        rows = conn.execute("SELECT job_id FROM known_jobs").fetchall()
    return {r["job_id"] for r in rows}

def save_job_history(job: dict):
    with get_conn() as conn:
        conn.execute("""
            INSERT OR IGNORE INTO job_history
            (job_id, title, location, postcode, pay, contract,
             hours, schedule, first_day, found_at, job_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            job["id"], job.get("title"), job.get("location"),
            job.get("postcode"), job.get("pay"), job.get("contract"),
            job.get("hours"), job.get("schedule"), job.get("firstDay"),
            job.get("found_at", now_london().isoformat()),
            json.dumps(job)
        ))

# ─── COOKIES ─────────────────────────────────────────────────────────────────
def save_cookies(account_id: int, cookies: list, hvhcid: str = ""):
    with get_conn() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO cookies (account_id, cookie_json, saved_at, hvhcid)
            VALUES (?, ?, ?, ?)
        """, (account_id, json.dumps(cookies), now_london().isoformat(), hvhcid))
    log.info(f"💾 [COOKIES] Saved {len(cookies)} cookies for account {account_id}")

def load_cookies(account_id: int = 1) -> list:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT cookie_json FROM cookies WHERE account_id = ?", (account_id,)
        ).fetchone()
    if row:
        return json.loads(row["cookie_json"])
    return []

def get_cookie_age_hours(account_id: int = 1) -> float | None:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT saved_at FROM cookies WHERE account_id = ?", (account_id,)
        ).fetchone()
    if row:
        from datetime import datetime
        saved = datetime.fromisoformat(row["saved_at"])
        now   = now_london()
        if saved.tzinfo is None:
            from config import TZ
            saved = saved.replace(tzinfo=TZ)
        return (now - saved).total_seconds() / 3600
    return None

# ─── ERRORS ──────────────────────────────────────────────────────────────────
def log_error(error_type: str, message: str):
    with get_conn() as conn:
        conn.execute("""
            INSERT INTO errors (error_type, message, occurred_at)
            VALUES (?, ?, ?)
        """, (error_type, message, now_london().isoformat()))

# ─── APPLICATIONS ─────────────────────────────────────────────────────────────
def save_application(job_id: str, app_id: str, status: str):
    now = now_london().isoformat()
    with get_conn() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO applications (job_id, app_id, status, prepared_at)
            VALUES (?, ?, ?, ?)
        """, (job_id, app_id, status, now))

def get_application(job_id: str) -> dict | None:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM applications WHERE job_id = ?", (job_id,)
        ).fetchone()
    return dict(row) if row else None
