"""
telegram_bot.py — alerts, commands, rate limiting for OWNER MODE v1
"""
import asyncio
import json
import logging
import re
import time
import aiohttp
from html import escape
from datetime import datetime
from config import CHAT_ID, TELEGRAM_API, now_london

log = logging.getLogger(__name__)

# ─── RATE LIMITER ─────────────────────────────────────────────────────────────
_tg_timestamps: list[float] = []
TG_MAX_PER_MINUTE = 20

async def _rate_limited_send(payload: dict):
    """Enforce max 20 Telegram messages per minute."""
    global _tg_timestamps
    now = time.monotonic()
    _tg_timestamps = [t for t in _tg_timestamps if now - t < 60]
    if len(_tg_timestamps) >= TG_MAX_PER_MINUTE:
        wait = 60 - (now - _tg_timestamps[0]) + 0.5
        log.info(f"[TG_RATELIMIT] Waiting {wait:.1f}s")
        await asyncio.sleep(wait)
    _tg_timestamps.append(time.monotonic())

# ─── CORE SEND ────────────────────────────────────────────────────────────────
async def tg_send(text: str, reply_markup=None, chat_id: str = None):
    cid     = chat_id or CHAT_ID
    payload = {"chat_id": cid, "text": text, "parse_mode": "HTML"}
    if reply_markup:
        payload["reply_markup"] = json.dumps(reply_markup)
    try:
        await _rate_limited_send(payload)
        async with aiohttp.ClientSession() as s:
            async with s.post(
                f"{TELEGRAM_API}/sendMessage",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=10)
            ) as r:
                if r.status not in [200, 201]:
                    text_resp = await r.text()
                    log.warning(f"[TG_SEND_FAILED] {r.status}: {text_resp[:200]}")
    except Exception as e:
        log.error(f"[TG_ERROR] {e}")
        from storage import log_error
        log_error("TELEGRAM_FAILED", str(e))

async def tg_admin(text: str):
    """Send message to owner only."""
    await tg_send(text, chat_id=CHAT_ID)

# ─── JOB ALERTS ──────────────────────────────────────────────────────────────
from job_parser import is_night_shift, is_fresh_job

async def tg_alert(job: dict, status: str = "new", chat_id: str = None,
                   distance=None, account_id=None, shift_index=None,
                   total_shifts=None, score=None, apply_url: str = None):
    cid = chat_id or CHAT_ID

    # Use pre-escaped fields if available, else escape now
    title    = job.get("title_safe")    or escape(job.get("title",""))
    location = job.get("location_safe") or escape(job.get("location","Unknown"))
    desc_raw = job.get("description","") or ""
    desc_str = f"\n📝 {escape(desc_raw)}" if desc_raw else ""

    headers_map = {
        "new":          "🚨 <b>NEW AMAZON JOB — ACT NOW!</b>",
        "applying":     f"🤖 <b>PREPARING APPLICATION{' (Acc '+str(account_id)+')' if account_id else ''}...</b>",
        "prepared":     "✅ <b>APPLICATION PREPARED — TAP TO SUBMIT!</b>",
        "applied":      "✅ <b>SUBMITTED!</b>",
        "ready":        "👆 <b>MANUAL APPLY NEEDED</b>",
        "fresh_alert":  "🌿 <b>AMAZON FRESH — MANUAL APPLY ONLY</b>",
        "cookie_expired": "⚠️ <b>COOKIES EXPIRED — ACTION NEEDED!</b>",
    }
    header = headers_map.get(status, "⚠️ <b>CHECK BOT</b>")

    pay_str  = job.get("pay_display") or f"{job.get('pay','?'):.2f}"
    dist_str = f"\n📏 Distance: <b>{distance} miles</b>" if distance else ""

    shifts   = job.get("shifts", [])
    schedule = job.get("schedule")
    if shift_index is not None and shifts and shift_index < len(shifts):
        schedule = shifts[shift_index]

    night     = " 🌙" if is_night_shift(schedule or "") else ""
    fresh     = " 🌿" if is_fresh_job(job) else ""
    perm      = " ⭐ PERMANENT" if "permanent" in job.get("contract","").lower() else ""
    shift_str = ""
    if total_shifts and total_shifts > 1 and shift_index is not None:
        shift_str = f"\n🔄 <b>Shift {shift_index+1}/{total_shifts}</b>"
    score_str = f"\n⭐ Score: <b>{score}</b>" if score else ""

    job_link  = apply_url or job.get("link","https://www.jobsatamazon.co.uk")

    text = f"""{header}{shift_str}{perm}
━━━━━━━━━━━━━━━━━━━━━
📍 <b>{location}</b>
📦 {title}{night}{fresh}
💰 <b>£{pay_str}/hr</b>
📋 {escape(job.get('contract','Seasonal'))}
📅 First Day: <b>{escape(str(job.get('firstDay') or 'See listing'))}</b>
🕘 Schedule: <b>{escape(str(schedule or 'See listing'))}</b>
🕐 Hours/Week: <b>{escape(str(job.get('hours') or 'See listing'))}</b>{dist_str}{score_str}{desc_str}
━━━━━━━━━━━━━━━━━━━━━"""

    if status == "prepared":
        text += "\n✅ <b>Shift selected — tap below to review and submit!</b>\n━━━━━━━━━━━━━━━━━━━━━"
    elif status == "applied":
        text += "\n🎉 <b>Check your Amazon Jobs dashboard!</b>\n━━━━━━━━━━━━━━━━━━━━━"
    elif status == "ready":
        text += "\n👆 <b>Tap to apply manually</b>\n━━━━━━━━━━━━━━━━━━━━━"
    elif status == "cookie_expired":
        text  = "⚠️ <b>AMAZON COOKIES EXPIRED</b>\n\nThe bot cannot prepare applications.\nPlease refresh your cookies and update AMAZON_COOKIES in Fly.io secrets."
    elif status == "fresh_alert":
        text += "\n🌿 <b>Fresh/Whole Foods — apply manually</b>\n━━━━━━━━━━━━━━━━━━━━━"

    markup = None
    if status in ["new","ready","prepared","fresh_alert"]:
        markup = {
            "inline_keyboard": [
                [{"text": "🚀 OPEN APPLICATION", "url": job_link}],
                [{"text": "✅ MARK SUBMITTED",   "callback_data": f"applied_{job['id']}"},
                 {"text": "❌ IGNORE",           "callback_data": f"skip_{job['id']}"}]
            ]
        }

    await tg_send(text, markup, chat_id=cid)


async def send_all_shifts(job: dict, status: str = "new", chat_id: str = None,
                          distance=None, score=None):
    shifts = job.get("shifts", [])
    if not shifts or len(shifts) <= 1:
        await tg_alert(job, status, chat_id=chat_id, distance=distance, score=score)
        return
    for i in range(len(shifts)):
        await tg_alert(job, status, chat_id=chat_id, distance=distance,
                       shift_index=i, total_shifts=len(shifts), score=score)
        await asyncio.sleep(0.5)

# ─── COMMAND HANDLER ─────────────────────────────────────────────────────────
async def handle_updates(state: dict):
    offset    = 0
    processed = set()

    while True:
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(
                    f"{TELEGRAM_API}/getUpdates?offset={offset}&timeout=10",
                    timeout=aiohttp.ClientTimeout(total=15)
                ) as r:
                    data = await r.json()
                    for update in data.get("result",[]):
                        uid    = update["update_id"]
                        offset = uid + 1
                        if uid not in processed:
                            processed.add(uid)
                            if len(processed) > 1000:
                                processed.clear()
                            await _process_update(update, state)
        except Exception as e:
            log.error(f"[UPDATE_ERROR] {e}")
        await asyncio.sleep(2)


async def _process_update(update: dict, state: dict):
    from config import get_proxy_url, is_peak_time, now_london

    if "callback_query" in update:
        cb = update["callback_query"]
        d  = cb.get("data","")
        cid = str(cb.get("message",{}).get("chat",{}).get("id", CHAT_ID))
        if d.startswith("applied_"):
            await tg_send("✅ Marked as submitted! Good luck! 💪", chat_id=cid)
        elif d.startswith("skip_"):
            await tg_send("❌ Job skipped.", chat_id=cid)
        return

    msg     = update.get("message",{})
    text    = msg.get("text","").strip()
    cid     = str(msg.get("chat",{}).get("id",""))
    text_lw = text.lower()

    # ── OWNER ONLY — block all non-owner commands ─────────────────────────
    if cid != CHAT_ID:
        log.info(f"[BLOCKED] Non-owner command from {cid}: {text}")
        return

    known_jobs  = state["known_jobs"]
    job_history = state["job_history"]
    accounts    = state["accounts"]

    if text_lw == "/start":
        await tg_send(f"""👑 <b>Amazon KING BOT — OWNER MODE v1</b>
━━━━━━━━━━━━━━━━━
✅ Running for owner only
📊 Jobs tracked: {len(known_jobs)}
📋 History: {len(job_history)}
🤖 Accounts: {len(accounts)}
━━━━━━━━━━━━━━━━━
Send /help for commands""")

    elif text_lw == "/status":
        from storage import get_cookie_age_hours
        peak      = is_peak_time()
        proxy     = "✅ Decodo UK" if get_proxy_url() else "❌ No proxy"
        speed     = "3s ⚡ PEAK" if peak else "10s 🔄 Normal"
        cookie_age = get_cookie_age_hours(1)
        cookie_str = f"{cookie_age:.1f}h ago" if cookie_age is not None else "Unknown"
        cookie_warn = " ⚠️ STALE" if cookie_age and cookie_age > 12 else ""
        now       = now_london()

        await tg_send(f"""📊 <b>Bot Status — OWNER MODE v1</b>
━━━━━━━━━━━━━━━━━
Status: {"⏸️ PAUSED" if state['bot_paused'] else "✅ RUNNING"}
🕐 London time: {now.strftime('%H:%M %Z')}
🌐 Proxy: {proxy}
🍪 Cookies saved: {cookie_str}{cookie_warn}
🤖 Accounts: {len(accounts)}
📦 Jobs tracked: {len(known_jobs)}
📋 History: {len(job_history)}
⚡ Scan speed: {speed}
🚀 Full submit: {"✅ ON" if __import__('os').environ.get('ENABLE_FULL_SUBMIT','false')=='true' else "⏸️ PREPARE ONLY"}
━━━━━━━━━━━━━━━━━""")

    elif text_lw == "/scrape":
        # Admin only — already enforced above
        await tg_send("🔍 <b>Manual scan started...</b>")
        from scheduler import check_jobs
        count = await check_jobs(state)
        await tg_send(
            f"✅ Scan complete\nNew: {count} | Tracked: {len(known_jobs)}\n"
            f"{'🎉 New jobs found!' if count > 0 else '⏳ No new jobs'}"
        )

    elif text_lw == "/jobs":
        if not known_jobs:
            await tg_send("📭 No jobs tracked yet — send /scrape to scan!")
        else:
            txt = f"📋 <b>Last {min(5,len(known_jobs))} Jobs:</b>\n━━━━━━━━━━━\n"
            for job in list(known_jobs.values())[-5:]:
                night = "🌙" if is_night_shift(job.get("schedule","")) else "☀️"
                sched = escape(str(job.get("schedule") or "See listing"))
                day   = escape(str(job.get("firstDay") or "See listing"))
                loc   = escape(job.get("location","?"))
                txt  += f"{night} {loc}\n💰 £{job.get('pay')}/hr | {escape(job.get('contract','?'))}\n📅 {day} | {sched[:30]}\n\n"
            await tg_send(txt)

    elif text_lw == "/history":
        if not job_history:
            await tg_send("📭 No history yet!")
        else:
            total  = len(job_history)
            avg    = sum(j.get("pay",0) for j in job_history) / total
            best   = max(job_history, key=lambda x: x.get("pay",0))
            nights = sum(1 for j in job_history if is_night_shift(j.get("schedule","")))
            await tg_send(f"""📊 <b>History</b>
Total: {total} | 🌙 Nights: {nights}
Avg: £{avg:.2f}/hr
Best: {escape(best.get('location','?'))} £{best.get('pay','?')}/hr""")

    elif text_lw == "/errors":
        from storage import get_conn
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT error_type, message, occurred_at FROM errors ORDER BY id DESC LIMIT 10"
            ).fetchall()
        if not rows:
            await tg_send("✅ No errors logged!")
        else:
            txt = "⚠️ <b>Recent Errors:</b>\n━━━━━━━━━━━\n"
            for r in rows:
                txt += f"[{r['occurred_at'][11:16]}] {escape(r['error_type'])}: {escape(r['message'][:80])}\n"
            await tg_send(txt)

    elif text_lw == "/test":
        test_job = {
            "id": "TEST-001", "title": "Warehouse Operative",
            "title_safe": "Warehouse Operative",
            "location": "Birmingham, England (Birmingham Area) B76 1AF",
            "location_safe": "Birmingham, England (Birmingham Area) B76 1AF",
            "postcode": "B76 1AF", "pay": 14.30, "pay_display": "14.30",
            "contract": "Seasonal | Full-time", "firstDay": "2026-05-20",
            "shifts": [
                "Sat, Sun, Mon, Tue 23:45 - 10:15",
                "Fri, Sat, Sun, Mon, Tue 6:30 - 13:00",
            ],
            "schedule": "Sat, Sun, Mon, Tue 23:45 - 10:15",
            "hours": "40",
            "description": "Pick, pack and ship parcels at our fulfilment centre.",
            "link": "https://www.jobsatamazon.co.uk",
        }
        await send_all_shifts(test_job, "new", chat_id=cid, distance=3.2, score=15)

    elif text_lw == "/pause":
        state["bot_paused"] = True
        await tg_send("⏸️ Bot paused.")

    elif text_lw == "/resume":
        state["bot_paused"] = False
        await tg_send("▶️ Bot resumed! 🔥")

    elif text_lw == "/clearcache":
        known_jobs.clear()
        await tg_send("🗑️ In-memory cache cleared.\n⚠️ SQLite known_jobs still persists — restart won't re-alert.")

    elif text_lw == "/cookies":
        from storage import get_cookie_age_hours, load_cookies
        cookies   = load_cookies(1)
        age       = get_cookie_age_hours(1)
        age_str   = f"{age:.1f} hours ago" if age is not None else "Unknown"
        warn      = "\n⚠️ <b>Cookies may be stale — consider refreshing!</b>" if age and age > 12 else ""
        await tg_send(f"""🍪 <b>Cookie Status</b>
━━━━━━━━━━━━━━━━━
Account 1: {len(cookies)} cookies
Last saved: {age_str}{warn}
━━━━━━━━━━━━━━━━━
To refresh: update AMAZON_COOKIES in Fly.io secrets""")

    elif text_lw == "/help":
        await tg_send("""👑 <b>Amazon KING BOT — OWNER MODE v1</b>
━━━━━━━━━━━━━━━━━
/start      — Welcome
/status     — Full bot status
/scrape     — Manual scan now
/jobs       — Last 5 jobs found
/history    — All-time stats
/cookies    — Cookie health check
/errors     — Recent error log
/test       — Test alert
/pause      — Pause scanning
/resume     — Resume scanning
/clearcache — Clear memory cache
━━━━━━━━━━━━━━━━━
🚀 Full submit: set ENABLE_FULL_SUBMIT=true in Fly.io
🌿 Fresh jobs = manual alert only""")
