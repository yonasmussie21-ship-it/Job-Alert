"""
amazon_scraper.py — scrape jobs via Playwright + Decodo proxy
Reuses one browser context across job detail fetches.
"""
import json
import re
import logging
import aiohttp
from playwright.async_api import async_playwright, Browser, BrowserContext
from config import get_proxy_url, now_london
from storage import load_cookies, save_cookies
from job_parser import parse_card

log = logging.getLogger(__name__)

# ─── SHARED BROWSER CONTEXT ──────────────────────────────────────────────────
_browser:  Browser        | None = None
_context:  BrowserContext | None = None
_playwright = None

async def get_browser_context():
    """Return shared Playwright context, launching once if needed."""
    global _browser, _context, _playwright
    if _context:
        return _context
    _playwright = await async_playwright().start()
    _browser    = await _playwright.chromium.launch(
        headless=True,
        args=["--no-sandbox","--disable-setuid-sandbox",
              "--disable-blink-features=AutomationControlled","--disable-gpu"]
    )
    _context = await _browser.new_context(
        user_agent=(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        ),
        locale="en-GB",
    )
    await _context.add_init_script(
        "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
    )
    await _context.route(
        "**/*.{png,jpg,jpeg,gif,svg,ico,woff,woff2,ttf,mp4,webp}",
        lambda route: route.abort()
    )
    saved = load_cookies()
    if saved:
        await _context.add_cookies(saved)
    log.info("[BROWSER] Shared context launched")
    return _context

async def close_browser():
    global _browser, _context, _playwright
    if _browser:
        await _browser.close()
        _browser = _context = None
    if _playwright:
        await _playwright.stop()
        _playwright = None
    log.info("[BROWSER] Context closed")

# ─── CORE SCRAPER ─────────────────────────────────────────────────────────────
async def fetch_jobs() -> list:
    """
    1. Load Amazon jobs page via shared Playwright context
    2. Capture GraphQL request
    3. Replay via Decodo UK proxy → ALL UK jobs
    4. Return parsed job list
    """
    log.info("[SCAN_STARTED]")
    all_jobs     = {}
    proxy        = get_proxy_url()
    captured     = {}
    direct_cards = []

    try:
        context = await get_browser_context()
        page    = await context.new_page()

        async def on_request(request):
            if "/graphql" in request.url and not captured:
                try:
                    body = request.post_data
                    if body and "searchJobCardsByLocation" in body:
                        headers = dict(request.headers)
                        for h in ["content-length","host",":method",":path",":scheme",":authority"]:
                            headers.pop(h, None)
                        try:
                            body_json  = json.loads(body)
                            search_req = body_json.get("variables",{}).get("searchJobRequest",{})
                            search_req["country"]  = "United Kingdom"
                            search_req["keyWords"] = ""
                            search_req["pageSize"] = 100
                            captured["body"] = json.dumps(body_json)
                        except:
                            captured["body"] = body
                        captured["url"]     = request.url
                        captured["headers"] = headers
                        log.info(f"[GRAPHQL_CAPTURED] {request.url}")
                except Exception as e:
                    log.warning(f"[CAPTURE_ERROR] {e}")

        async def on_response(response):
            if "/graphql" in response.url and response.status == 200:
                try:
                    data  = await response.json()
                    cards = (data.get("data",{})
                                 .get("searchJobCardsByLocation",{})
                                 .get("jobCards",[]))
                    if cards:
                        log.info(f"[BROWSER_JOBS] {len(cards)} intercepted directly")
                        direct_cards.extend(cards)
                except:
                    pass

        page.on("request",  on_request)
        page.on("response", on_response)

        await page.goto(
            "https://www.jobsatamazon.co.uk/app#/jobSearch?locale=en-GB&country=GBR",
            wait_until="domcontentloaded", timeout=60000
        )
        await page.wait_for_timeout(3000)

        if not captured:
            log.info("[SCROLL_TRIGGER] No GraphQL yet — scrolling...")
            await page.mouse.wheel(0, 3000)
            await page.wait_for_timeout(3000)
            await page.mouse.wheel(0, -3000)
            await page.wait_for_timeout(2000)

        # Save fresh cookies
        cookies = await context.cookies()
        if cookies:
            hvhcid = next((c["value"] for c in cookies if c["name"] == "hvhcid"), "")
            save_cookies(1, cookies, hvhcid)

        await page.close()

    except Exception as e:
        log.error(f"[BROWSER_ERROR] {e}")
        from storage import log_error
        log_error("BROWSER_ERROR", str(e))

    # Replay via Decodo → ALL UK jobs
    if captured and proxy:
        log.info("[PROXY_REPLAY] Replaying via Decodo UK proxy...")
        cards = await _replay_via_proxy(
            captured["url"], captured["headers"], captured["body"], proxy
        )
        if cards:
            log.info(f"[PROXY_JOBS] {len(cards)} jobs returned")
            for card in cards:
                job = parse_card(card)
                if job and job["id"] not in all_jobs:
                    all_jobs[job["id"]] = job
        else:
            log.warning("[PROXY_FAILED] Falling back to browser results")
            from storage import log_error
            log_error("PROXY_FAILED", "Decodo returned 0 jobs")
            for card in direct_cards:
                job = parse_card(card)
                if job and job["id"] not in all_jobs:
                    all_jobs[job["id"]] = job
    elif not proxy:
        log.warning("[NO_PROXY] No proxy configured — using browser results only")
        for card in direct_cards:
            job = parse_card(card)
            if job and job["id"] not in all_jobs:
                all_jobs[job["id"]] = job

    log.info(f"[SCAN_COMPLETE] {len(all_jobs)} unique warehouse jobs found")
    return list(all_jobs.values())


async def _replay_via_proxy(url, headers, body, proxy) -> list:
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                url, data=body, headers=headers, proxy=proxy,
                timeout=aiohttp.ClientTimeout(total=30)
            ) as response:
                if response.status != 200:
                    text = await response.text()
                    log.warning(f"[PROXY_STATUS] {response.status}: {text[:200]}")
                    return []
                try:
                    data = json.loads(await response.text())
                except:
                    log.warning("[PROXY_JSON_ERROR] Invalid JSON from proxy")
                    return []
                if "errors" in data:
                    log.warning(f"[GRAPHQL_ERROR] {json.dumps(data['errors'])[:200]}")
                    return []
                return (data.get("data",{})
                            .get("searchJobCardsByLocation",{})
                            .get("jobCards",[]))
    except Exception as e:
        log.error(f"[PROXY_ERROR] {e}")
        return []


# ─── JOB DETAILS (reuses shared context) ─────────────────────────────────────
async def fetch_job_details(job: dict) -> dict:
    try:
        context    = await get_browser_context()
        page       = await context.new_page()
        shifts_data = []

        async def handle_response(response):
            try:
                if "graphql" in response.url and response.status == 200:
                    data       = await response.json()
                    job_detail = data.get("data",{}).get("getJobDetailByJobId",{})
                    if job_detail:
                        shifts = job_detail.get("jobCardDetail",{}).get("scheduleDetails",[])
                        if shifts:
                            shifts_data.extend(shifts)
            except:
                pass

        page.on("response", handle_response)
        await page.goto(job["link"], wait_until="domcontentloaded", timeout=60000)
        await page.wait_for_timeout(4000)

        try:
            await page.wait_for_function(
                "() => document.body.innerText.split('Loading').length < 4",
                timeout=8000
            )
        except:
            pass

        content = await page.inner_text("body")

        # First Day
        for pattern in [
            r'(?:Tentative start date|Start date|First day)[:\s]+([A-Za-z]+,?\s+\d+\s+[A-Za-z]+\s+\d{4})',
            r'(?:Tentative start date|Start date|First day)[:\s]+([A-Za-z]+ \d+, \d{4})',
            r'(?:Tentative start date|Start date|First day)[:\s]+(\d{4}-\d{2}-\d{2})',
        ]:
            m = re.search(pattern, content, re.IGNORECASE)
            if m:
                job["firstDay"] = m.group(1).strip()
                break

        # Shifts
        shift_patterns = re.findall(
            r'([A-Za-z]{3}(?:,\s*[A-Za-z]{3})*\s+\d{1,2}:\d{2}\s*[-–]\s*\d{1,2}:\d{2})',
            content
        )
        if shift_patterns:
            unique          = list(dict.fromkeys(shift_patterns))
            job["shifts"]   = unique
            job["schedule"] = unique[0]
        elif shifts_data:
            job["shifts"]   = [s.get("scheduleDisplay","") for s in shifts_data if s.get("scheduleDisplay")]
            job["schedule"] = job["shifts"][0] if job["shifts"] else None

        # Hours
        m = re.search(r'(\d+)\s*(?:hrs?|hours?)\s*(?:per\s*week|/\s*week)', content, re.IGNORECASE)
        if m:
            job["hours"] = m.group(1)

        # Contract
        for ct in ["Permanent","Full-time","Fixed-term","Seasonal","Temporary","Part-time"]:
            if ct.lower() in content.lower():
                job["contract"] = ct
                break

        # Description
        desc_match = re.search(
            r'((?:Pick|Sort|Process|Receive|Load|Unload|Pack|Ship|Stow)[^.\n]{15,120}\.)',
            content, re.IGNORECASE
        )
        if desc_match:
            desc = desc_match.group(1).strip()
            if "Loading" not in desc and len(desc) >= 20:
                job["description"] = desc

        await page.close()
        log.info(f"[JOB_DETAILS] day={job.get('firstDay','?')} "
                 f"shifts={len(job.get('shifts',[]))} hrs={job.get('hours','?')}")

    except Exception as e:
        log.warning(f"[JOB_DETAILS_FAILED] {job.get('id')} — {e}")
        from storage import log_error
        log_error("JOB_DETAILS_FAILED", f"{job.get('id')}: {e}")
    return job
